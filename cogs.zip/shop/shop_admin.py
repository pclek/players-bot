import discord
from discord import app_commands
from discord.ext import commands
import aiosqlite
from datetime import datetime

from utils.checks import is_bot_admin

DB_PATH = "database/bot.db"

ADVENTURE_ITEM_SEED_ROWS = [
    # 낚시 재료
    ("붕어", "낚시"),
    ("고등어", "낚시"),
    ("연어", "낚시"),
    ("참치", "낚시"),
    ("장어", "낚시"),
    ("문어", "낚시"),
    ("복어", "낚시"),
    ("황금잉어", "낚시"),
    ("심해어", "낚시"),
    ("전설의심해어", "낚시"),

    # 농사 재료
    ("감자", "농사"),
    ("옥수수", "농사"),
    ("양파", "농사"),
    ("마늘", "농사"),
    ("허브", "농사"),
    ("고추", "농사"),
    ("당근", "농사"),
    ("버섯", "농사"),
    ("쌀", "농사"),
    ("황금호박", "농사"),

    # 광석/제련 재료
    ("석탄", "광산"),
    ("구리광석", "광산"),
    ("철광석", "광산"),
    ("은광석", "광산"),
    ("금광석", "광산"),
    ("미스릴광석", "광산"),
    ("다이아원석", "광산"),
    ("흑철광석", "광산"),
    ("비브라늄원석", "광산"),
    ("오리하르콘광석", "광산"),

    ("구리주괴", "제련"),
    ("철주괴", "제련"),
    ("은주괴", "제련"),
    ("금주괴", "제련"),
    ("미스릴주괴", "제련"),
    ("다이아결정", "제련"),
    ("흑철주괴", "제련"),
    ("비브라늄주괴", "제련"),
    ("오리하르콘주괴", "제련"),

    # 요리
    ("구운감자", "요리"),
    ("옥수수구이", "요리"),
    ("버섯구이", "요리"),
    ("붕어구이", "요리"),
    ("고등어구이", "요리"),
    ("허브감자", "요리"),
    ("매운붕어찜", "요리"),
    ("매운버섯볶음", "요리"),
    ("당근스튜", "요리"),
    ("장어구이", "요리"),
    ("옥수수수프", "요리"),
    ("야채볶음밥", "요리"),
    ("모둠채소볶음", "요리"),
    ("연어구이", "요리"),
    ("참치구이", "요리"),
    ("고등어스테이크", "요리"),
    ("연어스테이크", "요리"),
    ("문어숙회", "요리"),
    ("문어볶음", "요리"),
    ("참치스테이크", "요리"),
    ("장어덮밥", "요리"),
    ("참치피쉬앤칩스", "요리"),
    ("복어탕", "요리"),
    ("복어회정식", "요리"),
    ("황금잉어찜", "요리"),
    ("황금호박죽", "요리"),
    ("심해어스튜", "요리"),
    ("심해어만찬", "요리"),
    ("전설의심해어만찬", "요리"),
    ("황금정식", "요리"),

    # 장비
    ("녹슨검", "무기"),
    ("구리검", "무기"),
    ("철검", "무기"),
    ("은검", "무기"),
    ("금검", "무기"),
    ("미스릴검", "무기"),
    ("다이아검", "무기"),
    ("흑철검", "무기"),
    ("비브라늄검", "무기"),
    ("오리하르콘검", "무기"),

    ("철갑옷", "방어구"),
    ("은갑옷", "방어구"),
    ("금갑옷", "방어구"),
    ("미스릴갑옷", "방어구"),
    ("다이아갑옷", "방어구"),
    ("흑철갑옷", "방어구"),
    ("비브라늄갑옷", "방어구"),
    ("오리하르콘갑옷", "방어구"),

    # 기타 모험상품
    ("랜덤미끼", "기타"),
    ("랜덤씨앗", "기타"),
]


async def ensure_adventure_item_catalog():
    current_item_names = [name for name, category in ADVENTURE_ITEM_SEED_ROWS]
    placeholders = ",".join("?" for _ in current_item_names)

    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
        CREATE TABLE IF NOT EXISTS adventure_items (
            name TEXT PRIMARY KEY,
            category TEXT
        )
        """)

        for name, category in ADVENTURE_ITEM_SEED_ROWS:
            await db.execute("""
            INSERT INTO adventure_items (
                name,
                category
            )
            VALUES (?, ?)
            ON CONFLICT(name)
            DO UPDATE SET category = excluded.category
            """, (
                name,
                category,
            ))

        if current_item_names:
            await db.execute(f"""
            DELETE FROM adventure_items
            WHERE name NOT IN ({placeholders})
            """, current_item_names)

            try:
                await db.execute(f"""
                UPDATE adventure_shop_items
                SET enabled = 0
                WHERE item_name NOT IN ({placeholders})
                """, current_item_names)
            except aiosqlite.OperationalError:
                pass

        await db.commit()




def make_shop_admin_embed():
    return discord.Embed(
        title="🛒 상점 관리",
        description="아래 드롭다운에서 원하는 작업을 선택하세요.",
        color=discord.Color.blurple(),
    )


class ShopAdminBackButton(discord.ui.Button):
    def __init__(self):
        super().__init__(
            label="뒤로가기",
            style=discord.ButtonStyle.gray,
            emoji="↩️",
        )

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.edit_message(
            embed=make_shop_admin_embed(),
            content=None,
            view=ShopAdminMenuView(),
        )


class ShopItemModal(discord.ui.Modal):
    def __init__(self):
        super().__init__(title="상품 등록")

        self.name = discord.ui.TextInput(
            label="상품명",
            placeholder="예: 문화상품권 5천원",
            required=True,
            max_length=100,
        )

        self.description = discord.ui.TextInput(
            label="상품 설명",
            placeholder="예: 이벤트용 상품입니다.",
            required=True,
            style=discord.TextStyle.paragraph,
            max_length=500,
        )

        self.price = discord.ui.TextInput(
            label="가격",
            placeholder="숫자만 입력. 예: 5000",
            required=True,
            max_length=10,
        )

        self.stock = discord.ui.TextInput(
            label="재고",
            placeholder="숫자만 입력. 예: 3",
            required=True,
            max_length=10,
        )

        self.add_item(self.name)
        self.add_item(self.description)
        self.add_item(self.price)
        self.add_item(self.stock)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            price = int(str(self.price.value))
            stock = int(str(self.stock.value))
        except ValueError:
            await interaction.response.send_message(
                "❌ 가격과 재고는 숫자로 입력해주세요.",
                ephemeral=True,
            )
            return

        if price < 0:
            await interaction.response.send_message(
                "❌ 가격은 0 이상이어야 합니다.",
                ephemeral=True,
            )
            return

        if stock < 1:
            await interaction.response.send_message(
                "❌ 재고는 1개 이상이어야 합니다.",
                ephemeral=True,
            )
            return

        name = str(self.name.value).strip()
        description = str(self.description.value).strip()

        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("""
            INSERT INTO shop_items (
                name,
                description,
                price,
                stock,
                is_active,
                created_at
            )
            VALUES (?, ?, ?, ?, 1, ?)
            """, (
                name,
                description,
                price,
                stock,
                datetime.now().isoformat(),
            ))

            await db.commit()

        embed = discord.Embed(
            title="🛒 상품 등록 완료",
            color=discord.Color.green(),
        )

        embed.add_field(
            name="📦 상품명",
            value=f"`{name}`",
            inline=False,
        )

        embed.add_field(
            name="💰 가격",
            value=f"`{price}P`",
            inline=True,
        )

        embed.add_field(
            name="📦 재고",
            value=f"`{stock}개`",
            inline=True,
        )

        embed.add_field(
            name="📝 설명",
            value=f"`{description}`",
            inline=True,
        )

        await interaction.response.send_message(
            embed=embed,
            ephemeral=True,
        )

class AdventureShopPriceModal(discord.ui.Modal):
    def __init__(self, item_name: str):
        super().__init__(title=f"{item_name} 판매 설정")
        self.item_name = item_name

        self.price = discord.ui.TextInput(
            label="가격",
            placeholder="예: 10",
            required=True,
            max_length=10,
        )

        self.stock = discord.ui.TextInput(
            label="재고",
            placeholder="예: 100",
            required=True,
            max_length=10,
        )

        self.user_limit = discord.ui.TextInput(
            label="1인당 일일 구매 제한",
            placeholder="예: 20 / 비워두면 무제한",
            required=False,
            max_length=10,
        )

        self.add_item(self.price)
        self.add_item(self.stock)
        self.add_item(self.user_limit)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            price = int(str(self.price.value))
            stock = int(str(self.stock.value))
            user_limit_text = str(self.user_limit.value).strip()
            user_limit = int(user_limit_text) if user_limit_text else 0
        except ValueError:
            await interaction.response.send_message(
                "❌ 가격, 재고, 구매 제한은 숫자로 입력해주세요.",
                ephemeral=True,
            )
            return

        if price < 0 or stock < 1 or user_limit < 0:
            await interaction.response.send_message(
                "❌ 가격은 0 이상, 재고는 1 이상, 구매 제한은 0 이상이어야 합니다.",
                ephemeral=True,
            )
            return

        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("""
            SELECT id
            FROM adventure_shop_items
            WHERE item_name = ?
            """, (self.item_name,)) as cursor:
                exists = await cursor.fetchone()

            if exists:
                await db.execute("""
                UPDATE adventure_shop_items
                SET stock = stock + ?,
                    price = ?,
                    user_limit = ?,
                    enabled = 1
                WHERE item_name = ?
                """, (
                    stock,
                    price,
                    user_limit,
                    self.item_name,
                ))
            else:
                await db.execute("""
                INSERT INTO adventure_shop_items (
                    item_name,
                    price,
                    stock,
                    user_limit,
                    limit_type,
                    enabled
                )
                VALUES (?, ?, ?, ?, 'daily', 1)
                """, (
                    self.item_name,
                    price,
                    stock,
                    user_limit,
                ))

            await db.commit()

        await interaction.response.send_message(
            f"✅ 모험상품 `{self.item_name}` 등록 완료\n"
            f"가격: `{price}P` / 재고: `{stock}개` / 일일 제한: `{user_limit}개`",
        )



class AdventureShopCategorySelect(discord.ui.Select):
    def __init__(self, rows):
        options = []
        for (category,) in rows[:25]:
            options.append(
                discord.SelectOption(
                    label=category,
                    value=category,
                    description=f"{category} 아이템 보기",
                )
            )

        super().__init__(
            placeholder="판매할 카테고리를 선택하세요.",
            min_values=1,
            max_values=1,
            options=options,
        )

    async def callback(self, interaction: discord.Interaction):
        category = self.values[0]

        await ensure_adventure_item_catalog()

        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute(
                """
                SELECT name, category
                FROM adventure_items
                WHERE category = ?
                ORDER BY name
                """,
                (category,),
            ) as cursor:
                rows = await cursor.fetchall()

        view = discord.ui.View(timeout=60)
        view.add_item(AdventureShopItemSelect(rows))
        view.add_item(ShopAdminBackButton())

        await interaction.response.edit_message(
            content=f"🧭 {category} 카테고리 아이템 선택",
            embed=None,
            view=view,
        )

class AdventureShopItemSelect(discord.ui.Select):
    def __init__(self, rows):
        options = []

        for name, category in rows[:25]:
            options.append(
                discord.SelectOption(
                    label=name[:100],
                    value=name,
                    description=f"카테고리: {category}"[:100],
                )
            )

        super().__init__(
            placeholder="판매할 모험 아이템을 선택하세요.",
            min_values=1,
            max_values=1,
            options=options,
        )

    async def callback(self, interaction: discord.Interaction):
        item_name = self.values[0]

        await interaction.response.send_modal(
            AdventureShopPriceModal(item_name)
        )

class AdventureManageSelect(discord.ui.Select):
    def __init__(self, rows, mode):
        self.mode = mode

        options = []

        for item_id, item_name, price, stock in rows[:25]:
            options.append(
                discord.SelectOption(
                    label=item_name,
                    value=str(item_id),
                    description=f"{price}P / 재고 {stock}",
                )
            )

        super().__init__(
            placeholder="모험상품 선택",
            min_values=1,
            max_values=1,
            options=options,
        )

    async def callback(self, interaction: discord.Interaction):
        item_id = int(self.values[0])

        if self.mode == "delete":

            async with aiosqlite.connect(DB_PATH) as db:
                await db.execute("""
                DELETE FROM adventure_shop_items
                WHERE id = ?
                """, (item_id,))
                await db.commit()

            await interaction.response.edit_message(
                content="✅ 모험상품 삭제 완료",
                embed=None,
                view=None,
            )
            return

        await interaction.response.send_modal(
            AdventureEditModal(item_id)
        )

class AdventureEditModal(discord.ui.Modal):

    def __init__(self, item_id: int):
        super().__init__(title="모험상품 수정")

        self.item_id = item_id

        self.price = discord.ui.TextInput(
            label="가격",
            required=True,
        )

        self.stock = discord.ui.TextInput(
            label="재고",
            required=True,
        )

        self.limit = discord.ui.TextInput(
            label="일일 제한",
            required=False,
        )

        self.add_item(self.price)
        self.add_item(self.stock)
        self.add_item(self.limit)

    async def on_submit(self, interaction: discord.Interaction):

        try:
            price = int(self.price.value)
            stock = int(self.stock.value)
            limit = int(self.limit.value or 0)
        except ValueError:
            await interaction.response.send_message(
                "❌ 숫자만 입력해주세요.",
                ephemeral=True,
            )
            return

        async with aiosqlite.connect(DB_PATH) as db:

            await db.execute("""
            UPDATE adventure_shop_items
            SET
                price = ?,
                stock = ?,
                user_limit = ?
            WHERE id = ?
            """, (
                price,
                stock,
                limit,
                self.item_id,
            ))

            await db.commit()

        await interaction.response.send_message(
            "✅ 모험상품 수정 완료",
            ephemeral=True,
        )

class ShopItemSelect(discord.ui.Select):
    def __init__(self, rows, mode: str):
        self.mode = mode

        options = []

        for item_id, name, price, stock, is_active in rows[:25]:
            status = "판매중" if is_active else "중지"
            options.append(
                discord.SelectOption(
                    label=f"#{item_id} {name}",
                    value=str(item_id),
                    description=f"{price}P / 재고 {stock} / {status}",
                )
            )

        placeholder = "상품을 선택하세요."

        super().__init__(
            placeholder=placeholder,
            min_values=1,
            max_values=1,
            options=options,
        )

    async def callback(self, interaction: discord.Interaction):
        item_id = int(self.values[0])

        async with aiosqlite.connect(DB_PATH) as db:
            if self.mode == "stop":
                cursor = await db.execute("""
                UPDATE shop_items
                SET is_active = 0
                WHERE id = ?
                """, (item_id,))
                action_text = "판매중지"

            elif self.mode == "resume":
                cursor = await db.execute("""
                UPDATE shop_items
                SET is_active = 1
                WHERE id = ?
                AND stock > 0
                """, (item_id,))
                action_text = "판매재개"

            else:
                cursor = await db.execute("""
                DELETE FROM shop_items
                WHERE id = ?
                """, (item_id,))
                action_text = "삭제"

            await db.commit()

        if cursor.rowcount == 0:
            await interaction.response.send_message(
                "❌ 처리할 수 없는 상품입니다. 재고가 없거나 이미 삭제되었을 수 있습니다.",
                ephemeral=True,
            )
            return

        view = discord.ui.View(timeout=60)
        view.add_item(ShopAdminBackButton())

        await interaction.response.edit_message(
            content=f"✅ 상품 #{item_id} 을(를) {action_text}했습니다.",
            embed=None,
            view=view,
        )

class ShopLogChannelSelect(discord.ui.ChannelSelect):
    def __init__(self):
        super().__init__(
            placeholder="상점 로그 채널 선택",
            channel_types=[discord.ChannelType.text],
            min_values=1,
            max_values=1,
        )

    async def callback(self, interaction: discord.Interaction):
        channel = self.values[0]

        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("""
            INSERT INTO shop_settings (
                guild_id,
                log_channel_id
            )
            VALUES (?, ?)
            ON CONFLICT(guild_id) DO UPDATE SET
                log_channel_id = excluded.log_channel_id
            """, (
                interaction.guild.id,
                channel.id,
            ))

            await db.commit()

        embed = discord.Embed(
            title="🛒 상점 로그 채널 설정 완료",
            description=(
                f"📢 로그 채널\n"
                f"└ {channel.mention}"
            ),
            color=discord.Color.green(),
        )

        view = discord.ui.View(timeout=60)
        view.add_item(ShopAdminBackButton())

        await interaction.response.edit_message(
            content=None,
            embed=embed,
            view=view,
        )

class ShopBoardChannelSelect(discord.ui.ChannelSelect):
    def __init__(self):
        super().__init__(
            placeholder="상점 게시판 채널 선택",
            channel_types=[discord.ChannelType.text],
            min_values=1,
            max_values=1,
        )

    async def callback(self, interaction: discord.Interaction):
        channel = self.values[0]

        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("""
            INSERT INTO shop_settings (
                guild_id,
                shop_channel_id
            )
            VALUES (?, ?)
            ON CONFLICT(guild_id) DO UPDATE SET
                shop_channel_id = excluded.shop_channel_id
            """, (
                interaction.guild.id,
                channel.id,
            ))

            await db.commit()

        embed = discord.Embed(
            title="🛒 상점 게시판 설정 완료",
            description=(
                f"📌 상점 게시판\n"
                f"└ {channel.mention}\n\n"
                f"이 채널에 채팅이 올라오면 30분 쿨타임 기준으로 상점 목록이 하단에 갱신됩니다."
            ),
            color=discord.Color.green(),
        )

        view = discord.ui.View(timeout=60)
        view.add_item(ShopAdminBackButton())

        await interaction.response.edit_message(
            content=None,
            embed=embed,
            view=view,
        )

class InventoryStatusButton(discord.ui.Button):
    def __init__(self, label_text: str, status: str):
        super().__init__(
            label=label_text,
            style=discord.ButtonStyle.blurple,
        )

        self.status = status

    async def callback(self, interaction: discord.Interaction):
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("""
            SELECT id, user_id, item_name, status, purchased_at
            FROM inventory
            WHERE status = ?
            ORDER BY id DESC
            LIMIT 25
            """, (self.status,)) as cursor:
                rows = await cursor.fetchall()

        if not rows:
            await interaction.response.send_message(
                "❌ 해당 상태의 상품이 없습니다.",
                ephemeral=True,
            )
            return

        view = discord.ui.View(timeout=60)
        view.add_item(InventorySelect(rows, interaction.guild))
        view.add_item(ShopAdminBackButton())

        await interaction.response.edit_message(
            content="📦 상태를 변경할 상품을 선택하세요.",
            embed=None,
            view=view,
        )

class InventorySelect(discord.ui.Select):
    def __init__(self, rows, guild):
        self.guild = guild
        self.rows = rows

        options = []

        for inventory_id, user_id, item_name, status, purchased_at in rows:
            member = self.guild.get_member(user_id)

            if status == "pending":
                status_text = "지급대기"
            elif status == "completed":
                status_text = "사용완료"
            else:
                status_text = "취소됨"

            date_text = purchased_at[:10]

            if member:
                desc = member.display_name
            else:
                desc = f"탈퇴한 유저 ({user_id})"

            options.append(
                discord.SelectOption(
                    label=f"{desc} - {item_name}"[:100],
                    value=str(inventory_id),
                    description=f"{status_text} | {date_text}"[:100],
                )
            )

        super().__init__(
            placeholder="상태를 변경할 상품 선택",
            min_values=1,
            max_values=1,
            options=options,
        )

    async def callback(self, interaction: discord.Interaction):
        inventory_id = int(self.values[0])

        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("""
            SELECT user_id, item_name, status, purchased_at
            FROM inventory
            WHERE id = ?
            """, (inventory_id,)) as cursor:
                row = await cursor.fetchone()

        if not row:
            await interaction.response.send_message(
                "❌ 판매 정보를 찾을 수 없습니다.",
                ephemeral=True,
            )
            return

        user_id, item_name, status, purchased_at = row

        member = interaction.guild.get_member(user_id)

        if status == "pending":
            status_text = "⏳ 지급 대기"
        elif status == "completed":
            status_text = "✅ 사용 완료"
        else:
            status_text = "❌ 취소됨"

        embed = discord.Embed(
            title="📦 판매 정보",
            color=discord.Color.blurple(),
        )

        embed.add_field(
            name="👤 구매자",
            value=member.mention if member else f"`{user_id}`",
            inline=True,
        )

        embed.add_field(
            name="📦 상품",
            value=f"`{item_name}`",
            inline=True,
        )

        embed.add_field(
            name="📌 상태",
            value=f"`{status_text}`",
            inline=True,
        )

        embed.add_field(
            name="📅 구매일",
            value=f"`{purchased_at[:19]}`",
            inline=False,
        )

        view = discord.ui.View(timeout=60)

        view.add_item(
            InventoryUpdateButton(
                inventory_id,
                "✅ 사용 완료 처리",
                "completed",
                discord.ButtonStyle.green,
            )
        )

        view.add_item(
            InventoryUpdateButton(
                inventory_id,
                "❌ 취소 처리",
                "cancelled",
                discord.ButtonStyle.red,
            )
        )

        await interaction.response.edit_message(
            content=None,
            embed=embed,
            view=view,
        )


class InventoryUpdateButton(discord.ui.Button):
    def __init__(self, inventory_id, label_text, new_status, style):
        super().__init__(
            label=label_text,
            style=style,
        )

        self.inventory_id = inventory_id
        self.new_status = new_status

    async def callback(self, interaction: discord.Interaction):
        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("""
            SELECT user_id, item_id, item_name, status
            FROM inventory
            WHERE id = ?
            """, (self.inventory_id,)) as cursor:
                row = await cursor.fetchone()

            if not row:
                await interaction.response.send_message(
                    "❌ 상품 정보를 찾을 수 없습니다.",
                    ephemeral=True,
                )
                return

            user_id, item_id, item_name, old_status = row
            refund_amount = 0

            if self.new_status == "cancelled" and old_status != "cancelled":
                async with db.execute("""
                SELECT price
                FROM shop_purchase_logs
                WHERE buyer_id = ?
                AND item_id = ?
                ORDER BY id DESC
                LIMIT 1
                """, (user_id, item_id)) as cursor:
                    price_row = await cursor.fetchone()

                if price_row:
                    refund_amount = price_row[0]

                    await db.execute("""
                    UPDATE users
                    SET points = points + ?
                    WHERE user_id = ?
                    """, (refund_amount, user_id))

            await db.execute("""
            UPDATE inventory
            SET status = ?,
                completed_by = ?,
                completed_at = ?
            WHERE id = ?
            """, (
                self.new_status,
                interaction.user.id,
                datetime.now().isoformat(),
                self.inventory_id,
            ))

            await db.commit()

            # 로그채널 조회
            async with db.execute("""
            SELECT log_channel_id
            FROM shop_settings
            WHERE guild_id = ?
            """, (interaction.guild.id,)) as cursor:
                log_row = await cursor.fetchone()

        status_text = (
            "사용 완료"
            if self.new_status == "completed"
            else "취소됨"
        )

        embed = discord.Embed(
            title="🛠 판매 상태 변경 완료",
            description="관리자가 상품 처리 상태를 변경했습니다.",
            color=discord.Color.orange(),
        )

        embed.add_field(
            name="📦 상품",
            value=f"`{item_name}`",
            inline=False,
        )

        embed.add_field(
            name="📌 변경 상태",
            value=f"`{status_text}`",
            inline=True,
        )

        embed.add_field(
            name="👤 처리 관리자",
            value=interaction.user.mention,
            inline=True,
        )
        if refund_amount > 0:
            embed.add_field(
                name="💰 환불 포인트",
                value=f"`{refund_amount}P`",
                inline=True,
            )

        await interaction.response.send_message(
            embed=embed,
            ephemeral=True,
        )

        # 공개 로그
        if log_row:
            log_channel = interaction.guild.get_channel(log_row[0])

            if log_channel:
                log_embed = discord.Embed(
                    title="🛒 상품 상태 변경",
                    color=discord.Color.blurple(),
                )

                log_embed.add_field(
                    name="👤 구매자",
                    value=f"<@{user_id}>",
                    inline=True,
                )

                log_embed.add_field(
                    name="📦 상품",
                    value=f"`{item_name}`",
                    inline=True,
                )

                log_embed.add_field(
                    name="📌 상태",
                    value=f"`{status_text}`",
                    inline=False,
                )

                log_embed.add_field(
                    name="🛠 처리 관리자",
                    value=interaction.user.mention,
                    inline=False,
                )
                if refund_amount > 0:
                    log_embed.add_field(
                        name="💰 환불 포인트",
                        value=f"`{refund_amount}P`",
                        inline=False,
                    )

                await log_channel.send(embed=log_embed)        

class ShopAdminMenuSelect(discord.ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(
                label="상품 등록",
                description="포인트 상점에 새 상품을 등록합니다.",
                value="add",
            ),
            discord.SelectOption(
                label="모험상품 등록",
                description="랜덤미끼, 랜덤씨앗 등 모험 상품을 등록합니다.",
                value="adventure_add",
            ),
            discord.SelectOption(
                label="모험상품 수정",
                description="등록된 모험상품의 가격/재고를 수정합니다.",
                value="adventure_edit",
            ),

            discord.SelectOption(
                label="모험상품 삭제",
                description="등록된 모험상품을 삭제합니다.",
                value="adventure_delete",
            ),
            discord.SelectOption(
                label="상품 삭제",
                description="상품을 완전히 삭제합니다.",
                value="delete",
            ),
            discord.SelectOption(
                label="판매로그",
                description="상품 판매 상태를 관리합니다.",
                value="sales_log",
            ),
            discord.SelectOption(
                label="상품 판매중지",
                description="상품을 목록에서 숨기고 구매 불가로 만듭니다.",
                value="stop",
            ),
            discord.SelectOption(
                label="상품 판매재개",
                description="중지된 상품을 다시 판매 상태로 변경합니다.",
                value="resume",
            ),
            discord.SelectOption(
                label="상품 목록 조회",
                description="등록된 상품 목록을 확인합니다.",
                value="list",
            ),
            discord.SelectOption(
                label="상점로그채널 설정",
                description="구매 및 지급 로그 채널을 설정합니다.",
                value="log_channel",
            ),
            discord.SelectOption(
                label="상점게시판 설정",
                description="상점 목록이 유지될 채널을 설정합니다.",
                value="shop_board_channel",
            ),            
            
        ]

        super().__init__(
            placeholder="원하는 상점 관리 작업을 선택하세요.",
            min_values=1,
            max_values=1,
            options=options,
        )

    async def callback(self, interaction: discord.Interaction):
        selected = self.values[0]

        if selected == "add":
            await interaction.response.send_modal(
                ShopItemModal()
            )
            return

        if selected == "adventure_add":
            await ensure_adventure_item_catalog()

            async with aiosqlite.connect(DB_PATH) as db:
                async with db.execute("""
                SELECT DISTINCT category
                FROM adventure_items
                WHERE category IS NOT NULL
                AND category != ''
                ORDER BY category
                """) as cursor:
                    rows = await cursor.fetchall()

            if not rows:
                await interaction.response.send_message(
                    "❌ 등록 가능한 모험 아이템이 없습니다.",
                    ephemeral=True,
                )
                return

            view = discord.ui.View(timeout=60)
            view.add_item(AdventureShopCategorySelect(rows))
            view.add_item(ShopAdminBackButton())

            await interaction.response.edit_message(
                content="🧭 판매할 모험 아이템 카테고리를 선택하세요.",
                embed=None,
                view=view,
            )
            return
        if selected in ("adventure_edit", "adventure_delete"):

            async with aiosqlite.connect(DB_PATH) as db:

                async with db.execute("""
                SELECT
                    id,
                    item_name,
                    price,
                    stock
                FROM adventure_shop_items
                ORDER BY item_name
                """) as cursor:

                    rows = await cursor.fetchall()

            if not rows:
                await interaction.response.send_message(
                    "❌ 등록된 모험상품이 없습니다.",
                    ephemeral=True,
                )
                return

            view = discord.ui.View(timeout=60)

            view.add_item(
                AdventureManageSelect(
                    rows,
                    "delete" if selected == "adventure_delete" else "edit"
                )
            )

            view.add_item(
                ShopAdminBackButton()
            )

            await interaction.response.edit_message(
                content="모험상품 선택",
                embed=None,
                view=view,
            )
            return        
        if selected == "list":
            await send_shop_admin_list(interaction)
            return
        
        if selected == "log_channel":
            view = discord.ui.View(timeout=60)

            view.add_item(
                ShopLogChannelSelect()
            )
            view.add_item(ShopAdminBackButton())

            await interaction.response.edit_message(
                content="📢 상점 로그 채널을 선택하세요.",
                embed=None,
                view=view,
            )
            return
        
        if selected == "shop_board_channel":
            view = discord.ui.View(timeout=60)
            view.add_item(ShopBoardChannelSelect())
            view.add_item(ShopAdminBackButton())

            await interaction.response.edit_message(
                content="🛒 상점 게시판으로 사용할 채널을 선택하세요.",
                embed=None,
                view=view,
            )
            return        
        
        if selected == "sales_log":
            view = discord.ui.View(timeout=60)

            view.add_item(
                InventoryStatusButton(
                    "⏳ 지급 대기",
                    "pending",
                )
            )

            view.add_item(
                InventoryStatusButton(
                    "✅ 사용 완료",
                    "completed",
                )
            )

            view.add_item(
                InventoryStatusButton(
                    "❌ 취소됨",
                    "cancelled",
                )
            )
            view.add_item(ShopAdminBackButton())

            await interaction.response.edit_message(
                content="📦 조회할 판매 상태를 선택하세요.",
                embed=None,
                view=view,
            )
            return

        async with aiosqlite.connect(DB_PATH) as db:
            async with db.execute("""
            SELECT id, name, price, stock, is_active
            FROM shop_items
            ORDER BY id
            """) as cursor:
                rows = await cursor.fetchall()

        if not rows:
            await interaction.response.send_message(
                "❌ 등록된 상품이 없습니다.",
                ephemeral=True,
            )
            return
        
        view = discord.ui.View(timeout=60)
        view.add_item(ShopItemSelect(rows, selected))
        view.add_item(ShopAdminBackButton())

        await interaction.response.edit_message(
            content="처리할 상품을 선택하세요.",
            embed=None,
            view=view,
        )


class ShopAdminMenuView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=60)
        self.add_item(ShopAdminMenuSelect())


async def send_shop_admin_list(interaction: discord.Interaction):
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("""
        SELECT id, name, description, price, stock, is_active
        FROM shop_items
        ORDER BY id
        """) as cursor:
            rows = await cursor.fetchall()

    if not rows:
        view = discord.ui.View(timeout=60)
        view.add_item(ShopAdminBackButton())

        await interaction.response.edit_message(
            content="📋 등록된 상품이 없습니다.",
            embed=None,
            view=view,
        )
        return

    lines = []

    for item_id, name, description, price, stock, is_active in rows:
        status = "판매중" if is_active else "판매중지"

        preview = description.replace("\n", " ")
        if len(preview) > 80:
            preview = preview[:80] + "..."

        lines.append(
            f"📦 **상품명**\n"
            f"└ {name}\n\n"
            f"💰 **가격**        📦 **재고**        📝 **설명**\n"
            f"└ {price}P        └ {stock}개        └ {preview}\n\n"
            f"🔹 상태: `{status}`\n"
            f"━━━━━━━━━━━━━━━━━━"
    )

    embed = discord.Embed(
        title="🛒 상점 상품 목록",
        description="\n\n".join(lines),
        color=discord.Color.blurple(),
    )

    view = discord.ui.View(timeout=60)
    view.add_item(ShopAdminBackButton())

    await interaction.response.edit_message(
        content=None,
        embed=embed,
        view=view,
    )


class ShopAdmin(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="상점관리", description="포인트 상점 상품을 관리합니다.")
    async def shop_admin(self, interaction: discord.Interaction):
        if not await is_bot_admin(interaction):
            await interaction.response.send_message(
                "❌ 권한이 없습니다.",
                ephemeral=True,
            )
            return

        await interaction.response.send_message(
            embed=make_shop_admin_embed(),
            view=ShopAdminMenuView(),
            ephemeral=True,
        )


async def setup(bot: commands.Bot):
    await bot.add_cog(ShopAdmin(bot))